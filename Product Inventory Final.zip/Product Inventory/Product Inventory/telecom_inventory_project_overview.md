# Telecom Product Inventory Management with an AI CRUD Agent

## 1. Project summary

This project is a basic **telecom product inventory management system**. It manages telecom inventory records such as 5G routers, fiber modems, fiber-optic cables, network switches, antennas, and related equipment.

The core application is a **FastAPI backend** that performs Create, Read, Update, and Delete (CRUD) operations. Instead of a database, the project stores inventory data in a **CSV flat file**. The system will also include an **LLM-powered inventory agent** that lets a user perform the same CRUD operations using natural-language requests.

Postman is used to send requests and test the backend and agent endpoints.

## 2. Project goal

Build a simple, understandable, and demonstrable backend application that:

- Manages telecom product inventory through CRUD APIs.
- Stores data in a CSV flat file rather than a database.
- Validates product and stock information safely.
- Lets Postman test every endpoint.
- Adds an AI agent that understands inventory requests in natural language and performs approved CRUD operations through the existing backend logic.

The agent is an intelligent interface over the inventory system; it does not replace FastAPI, the business rules, or the CSV storage.

## 3. Business domain

The domain is telecom inventory. Example products include:

| Category | Example products |
| --- | --- |
| Network equipment | 5G routers, switches, access points |
| Fiber equipment | Fiber modems, optical network terminals, fiber-optic cables |
| Radio equipment | Antennas, signal boosters, radio units |
| Accessories | SIM devices, connectors, power adapters |

Each inventory item can include fields such as product ID, name, category, manufacturer, quantity, warehouse, and status.

## 4. Core requirements

### Data storage

- Use a flat file, preferably `inventory.csv`.
- Do not use MySQL, PostgreSQL, MongoDB, or another database for this project.
- The CSV file is the source of truth for inventory records.

### Standard CRUD API

The backend exposes standard FastAPI endpoints:

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `GET` | `/products` | List all products |
| `GET` | `/products/{product_id}` | Get one product by ID |
| `POST` | `/products` | Create a new product |
| `PUT` | `/products/{product_id}` | Update a product or its stock |
| `DELETE` | `/products/{product_id}` | Delete a product |

### AI agent API

The project also exposes an agent endpoint:

| Method | Endpoint | Purpose |
| --- | --- | --- |
| `POST` | `/agent/inventory-query` | Accept a natural-language inventory request and perform an approved CRUD action |

## 5. Recommended technology stack

| Layer | Technology | Reason |
| --- | --- | --- |
| Programming language | Python | Existing backend language; clear for an academic project |
| API framework | FastAPI | Defines routes, validates request models, and returns JSON responses |
| Server | Uvicorn | Runs the FastAPI application locally |
| Data storage | CSV flat file | Meets the flat-file requirement and is easy to inspect |
| Data/file handling | Python `csv` module | Reads and writes CSV data without a database |
| Validation | Pydantic / FastAPI models | Validates product fields and request bodies |
| AI layer | Tool-calling LLM | Understands natural language and selects permitted inventory operations |
| API testing | Postman | Sends and verifies CRUD and agent requests |
| Configuration | `.env` environment variables | Keeps any LLM API key out of source code |

## 6. Proposed architecture

```text
                         Standard API requests
Postman  ──────────────────────────────────────────► FastAPI routes
                                                     │
                                                     ▼
                                              Service layer
                                                     │
                                                     ▼
                                               CSV repository
                                                     │
                                                     ▼
                                               inventory.csv


                         Natural-language requests
Postman ─► POST /agent/inventory-query ─► Inventory agent
                                                │
                                                │ selects an approved tool
                                                ▼
                                           Service layer
                                                │
                                                ▼
                                           CSV repository
                                                │
                                                ▼
                                           inventory.csv
```

### Key design rule

The AI agent must **not** read or write `inventory.csv` directly. It must call approved backend service functions/tools. The service layer remains responsible for all validation, CRUD rules, and file operations.

This prevents the agent from bypassing inventory rules or corrupting data.

## 7. Data model

Suggested CSV format:

```csv
product_id,product_name,category,manufacturer,quantity,warehouse,status
R101,5G Router,Network Equipment,Nokia,8,Hyderabad,active
M202,Fiber Modem,Fiber Equipment,Huawei,50,Chennai,active
C303,Fiber Optic Cable,Accessories,Corning,120,Bengaluru,active
```

Suggested field rules:

| Field | Rule |
| --- | --- |
| `product_id` | Required and unique |
| `product_name` | Required |
| `category` | Required |
| `manufacturer` | Required or optional, based on backend design |
| `quantity` | Required non-negative integer |
| `warehouse` | Required |
| `status` | Example values: `active`, `inactive`, `discontinued` |

## 8. CRUD behavior

### Create

Creates a new product only when the product ID does not already exist.

Example request:

```json
{
  "product_id": "M202",
  "product_name": "Fiber Modem",
  "category": "Fiber Equipment",
  "manufacturer": "Huawei",
  "quantity": 50,
  "warehouse": "Hyderabad",
  "status": "active"
}
```

### Read

Lists all products, fetches a product by ID, or filters inventory for use cases such as low stock.

### Update

Updates allowed fields after confirming the product exists. Quantity must never become negative.

### Delete

Deletes a product only when its product ID exists. Agent-based deletions should require explicit confirmation.

## 9. AI agent design

### Agent purpose

The inventory agent converts natural-language requests into safe, structured CRUD operations. It is not an autonomous system and does not make unrestricted changes.

### Approved agent tools

| Tool | Operation |
| --- | --- |
| `list_products` | Read all or filtered products |
| `get_product` | Read one product by ID |
| `search_products` | Search by name, category, manufacturer, or warehouse |
| `get_low_stock_products` | Find products under a requested stock threshold |
| `create_product` | Create a validated product |
| `update_product` | Update product details |
| `update_product_stock` | Change inventory quantity |
| `delete_product` | Delete a product after confirmation |

### Agent examples

| Natural-language request | Expected tool |
| --- | --- |
| “Show all 5G routers with stock below 10.” | `get_low_stock_products` |
| “Find product R101.” | `get_product` |
| “Add a Huawei fiber modem with ID M202 and quantity 50.” | `create_product` |
| “Set stock for R101 to 40.” | `update_product_stock` |
| “Delete product M202.” | `delete_product` with confirmation |

### Missing or ambiguous information

If a request lacks required data, the agent should ask for it rather than guessing.

Example:

```text
User: “Add a router with quantity 20.”
Agent: “Please provide the product ID, product name, category, manufacturer, and warehouse.”
```

### Example agent request

```json
{
  "message": "Show all active 5G routers with stock below 10."
}
```

### Example agent response

```json
{
  "success": true,
  "operation": "get_low_stock_products",
  "message": "I found 1 active 5G router with stock below 10.",
  "data": [
    {
      "product_id": "R101",
      "product_name": "5G Router",
      "quantity": 8,
      "warehouse": "Hyderabad"
    }
  ]
}
```

## 10. Project structure

Suggested structure after agent integration:

```text
project-root/
├── app/
│   ├── main.py                 # FastAPI application entry point
│   ├── routes/                 # Product and agent endpoints
│   ├── models/                 # Pydantic request/response models
│   ├── services/               # Product CRUD and validation logic
│   ├── repositories/           # CSV read/write operations
│   └── agent/                  # Agent instructions and tool mapping
├── inventory.csv               # Flat-file inventory data
├── requirements.txt            # Python dependencies
├── .env.example                # Example environment variable names only
└── README.md                   # Setup and Postman instructions
```

The exact folder names can be adapted to the existing project. The priority is to avoid duplicating CRUD code between normal API routes and the agent.

## 11. Request flow

### Normal FastAPI CRUD request

```text
Postman sends POST /products
→ route validates request body
→ service checks business rules and duplicate ID
→ repository updates inventory.csv
→ FastAPI returns JSON response
```

### AI agent CRUD request

```text
Postman sends POST /agent/inventory-query
→ agent interprets the message
→ agent selects a permitted inventory tool
→ tool calls the existing service function
→ service validates the operation
→ repository reads/writes inventory.csv
→ agent returns a clear JSON response
```

## 12. Validation and safety

- Never hardcode an LLM API key; load it from environment variables.
- The agent can call only the approved inventory tools.
- The service layer validates every action, including actions initiated by the agent.
- Reject duplicate product IDs.
- Reject negative quantities.
- Return `404` for a missing product and clear validation errors for invalid requests.
- Require an explicit `confirm: true` value for agent-initiated deletion.
- The agent must not invent values or modify the CSV file itself.

## 13. Current status

| Area | Status |
| --- | --- |
| Telecom inventory use case | Defined |
| Flat-file storage requirement | Confirmed |
| Existing FastAPI CRUD backend | Already available |
| Basic CRUD endpoints | Already available / to be reviewed |
| Postman testing | Required for all endpoints |
| CSV schema | Recommended; confirm against current file |
| LLM agent architecture | Defined |
| Agent CRUD tools | Defined |
| Agent integration code | Pending |
| Environment variable configuration | Pending |
| README and Postman examples | Pending or to be updated |

## 14. Implementation plan

1. Review the existing FastAPI project and flat-file CRUD implementation.
2. Confirm or migrate the flat-file format to `inventory.csv` if appropriate.
3. Separate reusable product CRUD logic into service functions, if it is currently embedded directly inside routes.
4. Ensure the normal CRUD endpoints work in Postman.
5. Define Pydantic models for products and agent requests/responses.
6. Add approved agent tool definitions that call the service functions.
7. Add `POST /agent/inventory-query`.
8. Configure the LLM provider/API key through environment variables.
9. Test read, create, update, and confirmed delete requests through the agent endpoint in Postman.
10. Document setup, endpoints, example payloads, and limitations in the README.

## 15. Scope boundaries and limitations

This is intentionally a basic academic/demo project.

In scope:

- FastAPI backend
- CSV flat-file storage
- CRUD APIs
- Postman testing
- A single tool-calling inventory agent
- Natural-language CRUD requests

Out of scope:

- Database integration
- Frontend application
- Authentication and user roles
- RAG/document retrieval
- Multi-agent workflows
- Autonomous background actions
- Production-scale concurrent inventory updates

A CSV file is appropriate for a simple demonstration, but a production telecom inventory system would normally use a database, authentication, audit logs, transaction handling, and stronger concurrency controls.

## 16. Definition of done

The project is complete when:

- Products can be created, listed, fetched, updated, and deleted through FastAPI endpoints.
- Inventory data is stored correctly in the CSV flat file.
- All CRUD endpoints are successfully tested in Postman.
- The agent accepts natural-language inventory requests through `/agent/inventory-query`.
- The agent performs all CRUD operations only through approved backend tools/service functions.
- Invalid input, missing products, duplicate IDs, and invalid stock values produce clear errors.
- Agent deletion requires confirmation.
- Setup instructions and Postman examples are documented.
