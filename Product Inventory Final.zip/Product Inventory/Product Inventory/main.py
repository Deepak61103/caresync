"""
main.py
-------
FastAPI app exposing CRUD endpoints for a Telecom Product Inventory, plus a
natural-language AI agent endpoint. No database is used -- every request
flows through services.py (business rules) into file_utils.py (CSV I/O).

Run with:
    uvicorn main:app --reload

Then open http://127.0.0.1:8000/docs for interactive Swagger UI,
or import postman_collection.json into Postman.
"""

from fastapi import FastAPI, HTTPException, Query
from typing import List, Optional

from models import AgentQuery, AgentResponse, Product, ProductCreate, ProductUpdate
import agent
import services

app = FastAPI(
    title="Telecom Product Inventory API",
    description="A CRUD API for managing telecom products, backed by a flat CSV file, with an NLP agent endpoint.",
    version="1.1.0",
)


@app.get("/", tags=["Health"])
def root():
    """Simple health-check / welcome route."""
    return {"message": "Telecom Product Inventory API is running. Visit /docs for Swagger UI."}


# ---------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------
@app.post("/products", response_model=Product, status_code=201, tags=["Products"])
def create_product(product: ProductCreate):
    """
    Create a new product.
    - product_id is auto-generated (e.g. TEL001, TEL002, ...)
    - The new row is appended to products.csv
    """
    return services.create_product(
        product_name=product.product_name,
        category=product.category,
        brand=product.brand,
        price=product.price,
        stock_quantity=product.stock_quantity,
        status=product.status,
    )


# ---------------------------------------------------------------------
# READ (all + filter)
# ---------------------------------------------------------------------
@app.get("/products", response_model=List[Product], tags=["Products"])
def get_products(
    category: Optional[str] = Query(default=None, description="Filter by category, e.g. Router, SIM, Handset"),
    brand: Optional[str] = Query(default=None, description="Filter by brand, e.g. Jio, Airtel, Nokia"),
    status: Optional[str] = Query(default=None, description="Filter by status, e.g. Active"),
):
    """
    Get all products. Optionally filter by category, brand, and/or status, e.g.:
        /products?category=Router
        /products?brand=Jio
        /products?category=SIM&brand=Airtel
    """
    return services.list_products(category=category, brand=brand, status=status)


# ---------------------------------------------------------------------
# READ (single)
# ---------------------------------------------------------------------
@app.get("/products/{product_id}", response_model=Product, tags=["Products"])
def get_product(product_id: str):
    try:
        return services.get_product(product_id)
    except services.ServiceError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


# ---------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------
@app.put("/products/{product_id}", response_model=Product, tags=["Products"])
def update_product(product_id: str, update: ProductUpdate):
    """
    Update an existing product. Only the fields provided in the request
    body are changed; everything else stays the same.
    """
    try:
        return services.update_product(product_id, update.dict(exclude_unset=True))
    except services.ServiceError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


# ---------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------
@app.delete("/products/{product_id}", tags=["Products"])
def delete_product(product_id: str, confirm: bool = Query(default=False)):
    """
    Delete a product by ID. Requires ?confirm=true.
    """
    try:
        return services.delete_product(product_id, confirm=confirm)
    except services.ServiceError as e:
        raise HTTPException(status_code=e.status_code, detail=e.message)


# ---------------------------------------------------------------------
# AI AGENT
# ---------------------------------------------------------------------
@app.post("/agent/inventory-query", response_model=AgentResponse, tags=["Agent"])
def agent_inventory_query(query: AgentQuery):
    """
    Accepts a natural-language inventory request (e.g. "update price of
    product TEL001 to 100") and performs the matching approved CRUD
    operation through services.py. The agent never touches products.csv
    directly -- it only calls the same service functions the routes above use.
    """
    try:
        return agent.run_agent(query.message, confirm=query.confirm)
    except agent.AgentError as e:
        raise HTTPException(status_code=500, detail=str(e))
