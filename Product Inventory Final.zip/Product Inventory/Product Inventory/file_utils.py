"""
file_utils.py
--------------
This module is the ONLY place in the app that touches the CSV file directly.
Every CRUD route in main.py goes through these functions instead of opening
the file itself. This keeps the "flat file as database" logic centralized
and easy to reason about.

File layout (products.csv):
    product_id, product_name, category, brand, price, stock_quantity, status
"""

import csv
import os
from typing import List, Dict, Optional

CSV_FILE = os.path.join(os.path.dirname(__file__), "products.csv")

FIELDNAMES = [
    "product_id",
    "product_name",
    "category",
    "brand",
    "price",
    "stock_quantity",
    "status",
]


def _ensure_file_exists():
    """Create the CSV with just a header if it doesn't exist yet."""
    if not os.path.exists(CSV_FILE):
        with open(CSV_FILE, mode="w", newline="") as f:
            writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
            writer.writeheader()


def read_all_products() -> List[Dict]:
    """
    Reads the entire CSV file and returns it as a list of dictionaries.
    Numeric fields (price, stock_quantity) are cast from string to their
    real types since CSV stores everything as text.
    """
    _ensure_file_exists()
    products = []
    with open(CSV_FILE, mode="r", newline="") as f:
        reader = csv.DictReader(f)
        for row in reader:
            row["price"] = float(row["price"])
            row["stock_quantity"] = int(row["stock_quantity"])
            products.append(row)
    return products


def write_all_products(products: List[Dict]) -> None:
    """
    Overwrites the ENTIRE CSV file with the given list of product dicts.
    This is how update/delete work in a flat-file setup: read everything,
    modify the in-memory list, then rewrite the whole file.
    """
    with open(CSV_FILE, mode="w", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writeheader()
        for p in products:
            writer.writerow(p)


def get_product_by_id(product_id: str) -> Optional[Dict]:
    """Returns a single product dict matching product_id, or None."""
    for p in read_all_products():
        if p["product_id"] == product_id:
            return p
    return None


def get_next_id() -> str:
    """
    Auto-increment logic for product_id.
    IDs look like TEL001, TEL002, TEL003 ...
    We find the current max numeric suffix and add 1.
    """
    products = read_all_products()
    if not products:
        return "TEL001"

    max_num = 0
    for p in products:
        pid = p["product_id"]
        # Strip the "TEL" prefix and parse the number, e.g. "TEL003" -> 3
        try:
            num = int(pid.replace("TEL", ""))
            max_num = max(max_num, num)
        except ValueError:
            continue

    return f"TEL{max_num + 1:03d}"


def append_product(product: Dict) -> None:
    """Appends a single new product row to the CSV without rewriting everything."""
    _ensure_file_exists()
    with open(CSV_FILE, mode="a", newline="") as f:
        writer = csv.DictWriter(f, fieldnames=FIELDNAMES)
        writer.writerow(product)
