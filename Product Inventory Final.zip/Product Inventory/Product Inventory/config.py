"""
config.py
---------
Loads configuration from environment variables (via a local .env file).
Keeps the Groq API key out of source code, per the project's safety rules.
"""

import os

from dotenv import load_dotenv

load_dotenv()

GROQ_API_KEY = os.getenv("GROQ_API_KEY", "")
GROQ_MODEL = os.getenv("GROQ_MODEL", "openai/gpt-oss-120b")
