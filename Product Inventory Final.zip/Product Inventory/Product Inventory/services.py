"""
services.py
-----------
Business-logic layer. This is the ONLY layer that enforces inventory rules
(duplicate IDs, negative stock, missing products, delete confirmation, etc).

Both the normal FastAPI routes (main.py) and the AI agent (agent.py) call
these functions instead of touching file_utils.py directly. This guarantees
the agent can never bypass validation or write to the CSV on its own.
"""

from typing import Dict, List, Optional

import file_utils


class ServiceError(Exception):
    """Raised for any business-rule violation. Carries an HTTP-style status code."""

    def __init__(self, message: str, status_code: int = 400):
        super().__init__(message)
        self.message = message
        self.status_code = status_code


def list_products(
    category: Optional[str] = None,
    brand: Optional[str] = None,
    status: Optional[str] = None,
) -> List[Dict]:
    products = file_utils.read_all_products()

    if category:
        products = [p for p in products if p["category"].lower() == category.lower()]
    if brand:
        products = [p for p in products if p["brand"].lower() == brand.lower()]
    if status:
        products = [p for p in products if p["status"].lower() == status.lower()]

    return products


def get_product(product_id: str) -> Dict:
    product = file_utils.get_product_by_id(product_id)
    if not product:
        raise ServiceError(f"Product '{product_id}' not found", status_code=404)
    return product


def search_products(keyword: str) -> List[Dict]:
    """Case-insensitive search across product_name, category, and brand."""
    keyword = keyword.lower()
    products = file_utils.read_all_products()
    return [
        p
        for p in products
        if keyword in p["product_name"].lower()
        or keyword in p["category"].lower()
        or keyword in p["brand"].lower()
    ]


def get_low_stock_products(threshold: int) -> List[Dict]:
    products = file_utils.read_all_products()
    return [p for p in products if p["stock_quantity"] < threshold]


def create_product(
    product_name: str,
    category: str,
    brand: str,
    price: float,
    stock_quantity: int,
    status: str = "Active",
) -> Dict:
    if price <= 0:
        raise ServiceError("price must be greater than 0", status_code=400)
    if stock_quantity < 0:
        raise ServiceError("stock_quantity cannot be negative", status_code=400)

    new_product = {
        "product_id": file_utils.get_next_id(),
        "product_name": product_name,
        "category": category,
        "brand": brand,
        "price": price,
        "stock_quantity": stock_quantity,
        "status": status,
    }
    file_utils.append_product(new_product)
    return new_product


def update_product(product_id: str, updates: Dict) -> Dict:
    if "price" in updates and updates["price"] is not None and updates["price"] <= 0:
        raise ServiceError("price must be greater than 0", status_code=400)
    if (
        "stock_quantity" in updates
        and updates["stock_quantity"] is not None
        and updates["stock_quantity"] < 0
    ):
        raise ServiceError("stock_quantity cannot be negative", status_code=400)

    products = file_utils.read_all_products()
    for p in products:
        if p["product_id"] == product_id:
            p.update({k: v for k, v in updates.items() if v is not None})
            file_utils.write_all_products(products)
            return p

    raise ServiceError(f"Product '{product_id}' not found", status_code=404)


def update_product_stock(product_id: str, stock_quantity: int) -> Dict:
    return update_product(product_id, {"stock_quantity": stock_quantity})


def delete_product(product_id: str, confirm: bool = False) -> Dict:
    if not confirm:
        raise ServiceError(
            "Deleting a product requires explicit confirmation (confirm=true).",
            status_code=400,
        )

    products = file_utils.read_all_products()
    filtered = [p for p in products if p["product_id"] != product_id]

    if len(filtered) == len(products):
        raise ServiceError(f"Product '{product_id}' not found", status_code=404)

    file_utils.write_all_products(filtered)
    return {"message": f"Product '{product_id}' deleted successfully"}
