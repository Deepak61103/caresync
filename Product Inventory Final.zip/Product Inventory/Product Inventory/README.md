# Telecom Product Inventory API (FastAPI + CSV flat file + AI agent)

A CRUD API for managing telecom products (routers, SIM cards, handsets,
broadband plans, fiber equipment, etc). No database — all data lives in
`products.csv`. Includes a natural-language AI agent, powered by Groq's
tool-calling LLMs, that maps plain-English requests to the same approved
CRUD operations as the REST API.

## Project Structure
```
telecom_inventory_api/
├── main.py                  # FastAPI app & routes (thin — delegates to services.py)
├── services.py               # Business rules: validation, duplicate/negative checks, delete confirmation
├── agent.py                   # NLP agent: Groq tool-calling loop over services.py
├── config.py                   # Loads GROQ_API_KEY / GROQ_MODEL from .env
├── models.py                    # Pydantic request/response models
├── file_utils.py                  # CSV read/write logic (the "database layer")
├── products.csv                     # Flat-file data store (30 sample rows included)
├── requirements.txt
├── .env.example                       # Copy to .env and add your Groq API key
└── postman_collection.json             # Import into Postman to test all endpoints
```

## Architecture

```
Postman ──► FastAPI routes ──► services.py (validation/business rules) ──► file_utils.py ──► products.csv

Postman ──► POST /agent/inventory-query ──► agent.py (Groq tool-calling) ──► services.py ──► file_utils.py ──► products.csv
```

The agent **never reads or writes `products.csv` directly** — it only calls
the same `services.py` functions the REST routes use, so it can't bypass
validation or corrupt data.

## Setup

```bash
cd telecom_inventory_api
pip install -r requirements.txt
cp .env.example .env
# then edit .env and set GROQ_API_KEY=<your key from https://console.groq.com>
```

## Run the server

```bash
uvicorn main:app --reload
```

Server starts at: **http://127.0.0.1:8000**

- Interactive Swagger docs: http://127.0.0.1:8000/docs
- Alternative docs (ReDoc): http://127.0.0.1:8000/redoc

## Testing with Postman

1. Open Postman → Import → select `postman_collection.json`.
2. The collection includes a `base_url` variable already set to
   `http://127.0.0.1:8000`, and a `product_id` variable set to `TEL001`
   (change it to whatever ID you want to test with).
3. Requests included:
   - Health Check (`GET /`)
   - Create Product (`POST /products`)
   - Get All Products (`GET /products`, with optional `?category=` / `?brand=` / `?status=` filters)
   - Get Single Product (`GET /products/{product_id}`)
   - Update Product (`PUT /products/{product_id}`)
   - Delete Product (`DELETE /products/{product_id}?confirm=true`)
   - Agent - Update Price, Low Stock, Create Product, Delete (with confirmation) — all via `POST /agent/inventory-query`

## How the flat file works

- `products.csv` has columns: `product_id, product_name, category, brand, price, stock_quantity, status`
- **Create**: a new row is appended to the CSV; `product_id` is auto-generated
  as `TEL001`, `TEL002`, `TEL003`... by scanning existing IDs and adding 1.
- **Read**: the whole CSV is parsed into a list of dicts on every request
  (no in-memory caching — the file is always the source of truth).
- **Update**: all rows are read, the matching row is modified in memory,
  then the entire CSV is rewritten.
- **Delete**: all rows are read, the matching row is filtered out, then
  the entire CSV is rewritten. Requires `confirm=true`.

## The AI agent

`POST /agent/inventory-query` accepts a plain-English inventory request:

```json
{ "message": "update price of product TEL001 to 100" }
```

Internally:
1. The message is sent to a Groq LLM (default model: `openai/gpt-oss-120b`,
   configurable via `GROQ_MODEL` in `.env`) along with a fixed set of
   approved tools (`list_products`, `get_product`, `search_products`,
   `get_low_stock_products`, `create_product`, `update_product`,
   `update_product_stock`, `delete_product`).
2. The model picks the matching tool and extracts arguments (e.g.
   `update_product(product_id="TEL001", price=100)`).
3. `agent.py` calls the corresponding `services.py` function — the exact
   same validated code path the REST routes use.
4. The model is called once more with the tool's result to produce a
   short, plain-language acknowledgment.

Example response:
```json
{
  "success": true,
  "operation": "update_product",
  "message": "Updated TEL001 — price is now 100.",
  "data": {
    "product_id": "TEL001",
    "product_name": "5G Router X200",
    "category": "Router",
    "brand": "Jio",
    "price": 100.0,
    "stock_quantity": 150,
    "status": "Active"
  }
}
```

If a request is missing required information (e.g. "add a new router" with
no price), the agent asks for the missing fields instead of guessing.

Deleting requires explicit confirmation. Either phrase it in the message
("delete TEL021, I confirm") or pass the top-level `confirm: true` field;
without confirmation the agent will ask you to confirm rather than deleting.

## Example requests (curl)

**Create:**
```bash
curl -X POST http://127.0.0.1:8000/products \
  -H "Content-Type: application/json" \
  -d '{"product_name":"Fiber Broadband Plan","category":"Plan","brand":"Airtel","price":999.0,"stock_quantity":999,"status":"Active"}'
```

**Get all:**
```bash
curl http://127.0.0.1:8000/products
```

**Filter by category:**
```bash
curl "http://127.0.0.1:8000/products?category=Router"
```

**Update:**
```bash
curl -X PUT http://127.0.0.1:8000/products/TEL001 \
  -H "Content-Type: application/json" \
  -d '{"price":2299.0}'
```

**Delete:**
```bash
curl -X DELETE "http://127.0.0.1:8000/products/TEL001?confirm=true"
```

**Agent query:**
```bash
curl -X POST http://127.0.0.1:8000/agent/inventory-query \
  -H "Content-Type: application/json" \
  -d '{"message": "update price of product TEL001 to 100"}'
```

## Scope / limitations

This is intentionally a basic demo project: no database, no authentication,
no frontend UI, no multi-agent workflows, and no production-grade
concurrency handling. A real telecom inventory system would use a database,
auth, audit logging, and transactional writes.
