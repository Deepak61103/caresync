# Telecom Product Inventory API (FastAPI + CSV flat file)

A basic CRUD API for managing telecom products (routers, SIM cards, handsets,
broadband plans, etc.). No database — all data lives in `products.csv`.

## Project Structure
```
telecom_inventory_api/
├── main.py                  # FastAPI app & routes
├── models.py                 # Pydantic request/response models
├── file_utils.py              # CSV read/write logic (the "database layer")
├── products.csv                # Flat-file data store (sample data included)
├── requirements.txt
└── postman_collection.json    # Import into Postman to test all endpoints
```

## Setup

```bash
cd telecom_inventory_api
pip install -r requirements.txt
```

## Run the server

```bash
uvicorn main:app --reload
```

Server starts at: **http://127.0.0.1:8000**

- Interactive Swagger docs: http://127.0.0.1:8000/docs
- Alternative docs (ReDoc): http://127.0.0.1:8000/redoc

## Testing with Postman

1. Open Postman → Import → select `postman_collection.json`.
2. The collection includes a `base_url` variable already set to
   `http://127.0.0.1:8000`, and a `product_id` variable set to `TEL001`
   (change it to whatever ID you want to test with).
3. Requests included:
   - Health Check (`GET /`)
   - Create Product (`POST /products`)
   - Get All Products (`GET /products`)
   - Get Products Filtered by Category (`GET /products?category=Router`)
   - Get Products Filtered by Brand (`GET /products?brand=Jio`)
   - Get Single Product (`GET /products/{product_id}`)
   - Update Product (`PUT /products/{product_id}`)
   - Delete Product (`DELETE /products/{product_id}`)

## How the flat file works

- `products.csv` has columns: `product_id, product_name, category, brand, price, stock_quantity, status`
- **Create**: a new row is appended to the CSV; `product_id` is auto-generated
  as `TEL001`, `TEL002`, `TEL003`... by scanning existing IDs and adding 1.
- **Read**: the whole CSV is parsed into a list of dicts on every request
  (no in-memory caching — the file is always the source of truth).
- **Update**: all rows are read, the matching row is modified in memory,
  then the entire CSV is rewritten.
- **Delete**: all rows are read, the matching row is filtered out, then
  the entire CSV is rewritten.

## Sample data included

| product_id | product_name | category | brand | price | stock_quantity | status |
|---|---|---|---|---|---|---|
| TEL001 | 5G Router X200 | Router | Jio | 2499.0 | 150 | Active |
| TEL002 | 4G SIM Card | SIM | Airtel | 49.0 | 5000 | Active |
| TEL003 | Smartphone Edge 12 | Handset | Nokia | 15999.0 | 80 | Active |

## Example requests (curl)

**Create:**
```bash
curl -X POST http://127.0.0.1:8000/products \
  -H "Content-Type: application/json" \
  -d '{"product_name":"Fiber Broadband Plan","category":"Plan","brand":"Airtel","price":999.0,"stock_quantity":999,"status":"Active"}'
```

**Get all:**
```bash
curl http://127.0.0.1:8000/products
```

**Filter by category:**
```bash
curl "http://127.0.0.1:8000/products?category=Router"
```

**Update:**
```bash
curl -X PUT http://127.0.0.1:8000/products/TEL001 \
  -H "Content-Type: application/json" \
  -d '{"price":2299.0}'
```

**Delete:**
```bash
curl -X DELETE http://127.0.0.1:8000/products/TEL001
```
