"""
main.py
-------
FastAPI app exposing CRUD endpoints for a Telecom Product Inventory.
No database is used — every request reads from / writes to products.csv
via the helper functions in file_utils.py.

Run with:
    uvicorn main:app --reload

Then open http://127.0.0.1:8000/docs for interactive Swagger UI,
or import postman_collection.json into Postman.
"""

from fastapi import FastAPI, HTTPException, Query
from typing import List, Optional

from models import Product, ProductCreate, ProductUpdate
import file_utils

app = FastAPI(
    title="Telecom Product Inventory API",
    description="A basic CRUD API for managing telecom products, backed by a flat CSV file instead of a database.",
    version="1.0.0",
)


@app.get("/", tags=["Health"])
def root():
    """Simple health-check / welcome route."""
    return {"message": "Telecom Product Inventory API is running. Visit /docs for Swagger UI."}


# ---------------------------------------------------------------------
# CREATE
# ---------------------------------------------------------------------
@app.post("/products", response_model=Product, status_code=201, tags=["Products"])
def create_product(product: ProductCreate):
    """
    Create a new product.
    - product_id is auto-generated (e.g. TEL001, TEL002, ...)
    - The new row is appended to products.csv
    """
    new_id = file_utils.get_next_id()
    new_product = {
        "product_id": new_id,
        "product_name": product.product_name,
        "category": product.category,
        "brand": product.brand,
        "price": product.price,
        "stock_quantity": product.stock_quantity,
        "status": product.status,
    }
    file_utils.append_product(new_product)
    return new_product


# ---------------------------------------------------------------------
# READ (all + filter/search)
# ---------------------------------------------------------------------
@app.get("/products", response_model=List[Product], tags=["Products"])
def get_products(
    category: Optional[str] = Query(default=None, description="Filter by category, e.g. Router, SIM, Handset"),
    brand: Optional[str] = Query(default=None, description="Filter by brand, e.g. Jio, Airtel, Nokia"),
):
    """
    Get all products. Optionally filter by category and/or brand
    using query params, e.g.:
        /products?category=Router
        /products?brand=Jio
        /products?category=SIM&brand=Airtel
    """
    products = file_utils.read_all_products()

    if category:
        products = [p for p in products if p["category"].lower() == category.lower()]
    if brand:
        products = [p for p in products if p["brand"].lower() == brand.lower()]

    return products


# ---------------------------------------------------------------------
# READ (single)
# ---------------------------------------------------------------------
@app.get("/products/{product_id}", response_model=Product, tags=["Products"])
def get_product(product_id: str):
    """Get a single product by its ID."""
    product = file_utils.get_product_by_id(product_id)
    if not product:
        raise HTTPException(status_code=404, detail=f"Product '{product_id}' not found")
    return product


# ---------------------------------------------------------------------
# UPDATE
# ---------------------------------------------------------------------
@app.put("/products/{product_id}", response_model=Product, tags=["Products"])
def update_product(product_id: str, update: ProductUpdate):
    """
    Update an existing product. Only the fields provided in the request
    body are changed; everything else stays the same.
    Internally: read all rows -> modify the matching one -> rewrite the CSV.
    """
    products = file_utils.read_all_products()

    for p in products:
        if p["product_id"] == product_id:
            update_data = update.dict(exclude_unset=True)
            p.update(update_data)
            file_utils.write_all_products(products)
            return p

    raise HTTPException(status_code=404, detail=f"Product '{product_id}' not found")


# ---------------------------------------------------------------------
# DELETE
# ---------------------------------------------------------------------
@app.delete("/products/{product_id}", tags=["Products"])
def delete_product(product_id: str):
    """
    Delete a product by ID.
    Internally: read all rows -> filter out the matching one -> rewrite the CSV.
    """
    products = file_utils.read_all_products()
    filtered = [p for p in products if p["product_id"] != product_id]

    if len(filtered) == len(products):
        raise HTTPException(status_code=404, detail=f"Product '{product_id}' not found")

    file_utils.write_all_products(filtered)
    return {"message": f"Product '{product_id}' deleted successfully"}
